kill  `cat process.pid`
rm -rf process.pid